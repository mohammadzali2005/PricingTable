// document.querySelectorAll('tr:not(tr:first-child)').forEach(tableRow => {
//     tableRow.addEventListener('mouseover', () => {

//         const willChangeElements = {
//             planTitles : document.querySelectorAll('.planTitle'),
//             planPrices : document.querySelectorAll('.planPrice'),
//             planTimes : document.querySelectorAll('.planTime'),
//             tableColElements : document.querySelectorAll('tr:not(tr:first-child) td:not(td:last-child)'),
//             tableColLastChild : document.querySelectorAll('tr:not(tr:first-child) td:last-child')
//         }

//         console.log('Working');

//     });
// })